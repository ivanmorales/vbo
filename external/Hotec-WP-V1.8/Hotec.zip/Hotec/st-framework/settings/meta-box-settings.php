<?php
/*
$st_sidebars = st_get_setting("sidebars",array());

foreach($st_sidebars as $sb){
    $sidebar_options[$sb['id']]= $sb['title'];
}


$st_default_meta_boxs_options = array(
    
        array(
                'name'=>'gallery',
                'title'=>'Gallery',
                'type' =>'gallery',
                'default'=>'',
                'desc'=>'',
                'desc_bottom'=>''
             ),

          array(
                'name'=>'sidebar',
                'title'=>'Sidebar',
                'type' =>'select',
                'multiple'=> true,
                'options'=> $sidebar_options,
                'default'=>array(),
                'desc'=>'',
                'desc_bottom'=>''
             ),
          array(
            'name'=>'unlimit',
            'title'=>'Unlimit',
            'type' =>'ui', // tabs, arcodition
            'default'=>array(),
            'desc'=>'',
            'desc_bottom'=>''
         ),
         array(
            'name'=>'unlimit2',
            'title'=>'Unlimit2',
            'type' =>'ui', // tabs, arcodition
            'default'=>array(),
            'desc'=>'',
            'desc_bottom'=>''
         )
            
);



$st_default_meta_box['tab_theme_options']['tab_title'] = 'Default Options';
$st_default_meta_box['tab_theme_options']['name'] ='smooththemes_meta_options';
$st_default_meta_box['tab_theme_options']['options'] = $st_default_meta_boxs_options;


st_add_metabox(array('post','page'),'smooththemes_meta_options', 'Smootheme Options', $st_default_meta_box);

*/
