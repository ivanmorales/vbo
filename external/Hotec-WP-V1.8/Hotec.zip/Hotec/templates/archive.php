<?php 
 include(ST_TEMPLATE_DIR.'list-post.php');
?>